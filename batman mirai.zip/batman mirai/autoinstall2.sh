clear 
echo "make sure u ran ~ autoinstall.sh"
echo "you will be happy to hear its all automatic from now!"
cd ~/; chmod 0777 * -R; sh build.sh