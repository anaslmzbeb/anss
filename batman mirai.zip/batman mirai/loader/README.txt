Greetings, my name is Z0lh and today im giving some of my telnet lsts out cuz im leaving the scene and i dont need them anymore.
(you probably havent never heard of me).
Have fun boys and girls!

[!] not sure will these pull anymore (while ago these lists pulled 10k bots easily)

